/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visual;

import javax.swing.JLabel;

/**
 *
 * @author Usuario
 */
public class Movimiento extends Thread {

    private boolean ejecutando;
    private JLabel carros;
    private int startX;
    private int startY;
    private int endX;
    private int endY;
    private int step;

    public Movimiento(JLabel carros, int startX, int startY, int endX, int endY, int step) {
        
        this.carros = carros;
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;
        this.step = step;
        this.ejecutando = true;
    }

    public void restaurarPosicionInicial() {
        carros.setLocation(startX, startY);
    }
    
    public void detenerMovimiento() {
        
        ejecutando = false;
    }
    
    @Override
    public void run() {
        
        int currentX = startX;
        int currentY = startY;

        while (currentX != endX || currentY != endY) {
            if (currentX < endX) {
                currentX += step;
                if (currentX > endX) {
                    currentX = endX;
                }
            } else if (currentX > endX) {
                currentX -= step;
                if (currentX < endX) {
                    currentX = endX;
                }
            }

            if (currentY < endY) {
                currentY += step;
                if (currentY > endY) {
                    currentY = endY;
                }
            } else if (currentY > endY) {
                currentY -= step;
                if (currentY < endY) {
                    currentY = endY;
                }
            }

            carros.setLocation(currentX, currentY);

            try {
                Thread.sleep(50); 
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
