/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visual;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 *
 * @author Usuario
 */
public class Cronometro extends Carrera{
    private JLabel labelTiempo;
    private JButton botonIniciar;
    private JButton botonDetener;

    private boolean ejecutando;
    private Thread hiloCronometro;
    private int segundos;

    public Cronometro() {
        setTitle("Cronómetro");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        labelTiempo = new JLabel("0");
        labelTiempo.setFont(new Font("Arial", Font.BOLD, 24));
        add(labelTiempo);

        botonIniciar = new JButton("Iniciar");
        botonIniciar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                iniciarCronometro();
            }
        });
        add(botonIniciar);

        botonDetener = new JButton("Detener");
        botonDetener.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                detenerCronometro();
            }
        });
        add(botonDetener);
    }

    private void iniciarCronometro() {
        ejecutando = true;
        segundos = 0;

        hiloCronometro = new Thread(new Runnable() {
            @Override
            public void run() {
                while (ejecutando) {
                    try {
                        Thread.sleep(1000);
                        segundos++;
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                labelTiempo.setText(Integer.toString(segundos));
                            }
                        });
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        hiloCronometro.start();
    }

    private void detenerCronometro() {
        ejecutando = false;
        hiloCronometro.interrupt();
    }
}

