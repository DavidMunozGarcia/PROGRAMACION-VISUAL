/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Visual;

import java.awt.Point;
import java.awt.GridLayout;

import javax.swing.*;
import java.awt.BorderLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;

/**
 *
 * @author Usuario
 */
public class Carrera extends javax.swing.JFrame {
    
    private Movimiento mover1;
    private Movimiento mover2;
    private Movimiento mover3;

    private Clip clip;
    private boolean ejecutando;
    private Thread hiloCronometro;
    private int segundos;
    
     private void iniciarCronometro() {
        ejecutando = true;
        segundos = 0;

        hiloCronometro = new Thread(new Runnable() {
            @Override
            public void run() {
                while (ejecutando) {
                    try {
                        Thread.sleep(1000);
                        segundos++;
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                aa.setText("El tiempo es" +Integer.toString(segundos));
                            }
                        });
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
            }
        });

        hiloCronometro.start();
    }
      private void detenerCronometro() {
        ejecutando = false;
        hiloCronometro.interrupt();
    }
    
      

    public void Sonido(ActionEvent e) {
        if (e.getSource() == Carrera) {
            reproducirAudio();
        } else if (e.getSource() == carnegro.getComponentAt(620, 70)) {
            detenerAudio();
        }
    }

    public void reproducirAudio() {
        try {
            File file = new File("C:\\Users\\GAMER PC\\Documents\\PropPlaneExteriorS PE062201.wav");
            AudioInputStream audioStream = AudioSystem.getAudioInputStream(file);

            clip = AudioSystem.getClip();
            clip.open(audioStream);
            clip.start();
        } catch (LineUnavailableException | IOException | UnsupportedAudioFileException ex) {
            ex.printStackTrace();
        }
    }

    public void detenerAudio() {
        if (clip != null && clip.isRunning()) {
            clip.stop();
        }
    }

    public void movimiento() {
    Random random1 = new Random();
    int randomNumber1 = random1.nextInt(5) + 1;
    Random random2 = new Random();
    int randomNumber2 = random2.nextInt(5) + 1;
    Random random3 = new Random();
    int randomNumber3 = random3.nextInt(5) + 1;

    mover1 = new Movimiento(carverde, 60, 70, 620, 70, randomNumber1);
    mover1.start();

    mover2 = new Movimiento(carnegro, 60, 330, 620, 330, randomNumber2);
    mover2.start();

    mover3 = new Movimiento(carrojo, 60, 580, 620, 580, randomNumber3);
    mover3.start();

    Thread hiloGanador = new Thread(new Runnable() {
        @Override
        public void run() {
            while (true) {
                if (carverde.getLocation().x >= 620) {
                    aa.setText("El ganador es el carro verde!");
                    terminarCarrera();
                    break;
                } else if (carnegro.getLocation().x >= 620) {
                    aa.setText("El ganador es el carro negro!");
                    terminarCarrera();
                    break;
                } else if (carrojo.getLocation().x >= 620) {
                    aa.setText("El ganador es el carro rojo!");
                    terminarCarrera();
                    break;
                }
            }
        }
    });
    hiloGanador.start();
}

    private void detenerMovimiento() {
    ejecutando = false;
        hiloCronometro.interrupt();
}

    
    public Carrera() {
        initComponents();
        this.setLocationRelativeTo(null);

    }

    public void volver() {
        Random random1 = new Random();
        int randomNumber1 = random1.nextInt(5) + 1;
        Random random2 = new Random();
        int randomNumber2 = random2.nextInt(5) + 1;
        Random random3 = new Random();
        int randomNumber3 = random3.nextInt(5) + 1;

        Movimiento mover1 = new Movimiento(carverde, 620, 70, 60, 70, 100000);
        mover1.start();

        Movimiento mover2 = new Movimiento(carnegro, 620, 330, 60, 330, 100000);
        mover2.start();

        Movimiento mover3 = new Movimiento(carrojo, 620, 580, 60, 580, 100000);
        mover3.start();
    }
    
    public class Podio {
    private String primerLugar;
    private String segundoLugar;
    private String tercerLugar;
    private double tiempoTotal;

    public Podio(String primerLugar, String segundoLugar, String tercerLugar, double tiempoTotal) {
        this.primerLugar = primerLugar;
        this.segundoLugar = segundoLugar;
        this.tercerLugar = tercerLugar;
        this.tiempoTotal = tiempoTotal;
    }

    // Métodos getters y setters para acceder y modificar los valores de las variables privadas

    public String getPrimerLugar() {
        return primerLugar;
    }

    public void setPrimerLugar(String primerLugar) {
        this.primerLugar = primerLugar;
    }

    public String getSegundoLugar() {
        return segundoLugar;
    }

    public void setSegundoLugar(String segundoLugar) {
        this.segundoLugar = segundoLugar;
    }

    public String getTercerLugar() {
        return tercerLugar;
    }

    public void setTercerLugar(String tercerLugar) {
        this.tercerLugar = tercerLugar;
    }

    public double getTiempoTotal() {
        return tiempoTotal;
    }

    public void setTiempoTotal(double tiempoTotal) {
        this.tiempoTotal = tiempoTotal;
    }

    // Método que muestra los resultados del podio

    public void mostrarPodio() {
        System.out.println("Primer lugar: " + primerLugar);
        System.out.println("Segundo lugar: " + segundoLugar);
        System.out.println("Tercer lugar: " + tercerLugar);
        System.out.println("Tiempo total: " + tiempoTotal + " segundos");
    }
}
    
    private void terminarCarrera() {
        if (mover1 != null) {
            mover1.detenerMovimiento();
        }
        if (mover2 != null) {
            mover2.detenerMovimiento();
        }
        if (mover3 != null) {
            mover3.detenerMovimiento();
        }
    detenerCronometro();
    detenerAudio();
    mover1.detenerMovimiento();
    mover2.detenerMovimiento();
    mover3.detenerMovimiento();
}

    private String getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    private String getDistanciaRecorrida() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public class Podio2 extends JDialog {
    private JLabel podioLabel;
    private JButton cerrarButton;

    public Podio2(JFrame parent, String tiempo, String primerLugar, String segundoLugar, String tercerLugar) {
        super(parent, true);
        setTitle("Podio");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(400, 300);
        setLocationRelativeTo(parent);

        podioLabel = new JLabel();
        podioLabel.setVerticalAlignment(SwingConstants.TOP);
        podioLabel.setText("<html><h1>Podio</h1>"
                + "<p>Tiempo: " + tiempo + "</p>"
                + "<ol>"
                + "<li>" + primerLugar + "</li>"
                + "<li>" + segundoLugar + "</li>"
                + "<li>" + tercerLugar + "</li>"
                + "</ol></html>");
        getContentPane().add(podioLabel, BorderLayout.CENTER);

        cerrarButton = new JButton("Cerrar");
        cerrarButton.addActionListener(e -> dispose());
        getContentPane().add(cerrarButton, BorderLayout.SOUTH);
    }

    public void mostrar() {
        setVisible(true);
    }
}
    

   public void mostrarPodio(Carrera[] corredores, long tiempo) {
    JFrame ventanaPodio = new JFrame("Podio");
    JPanel panelPodio = new JPanel(new GridLayout(4, 2));

    JLabel titulo = new JLabel("PODIO", SwingConstants.CENTER);
    JLabel primerLugar = new JLabel("1er Lugar: " + corredores[0].getNombre() + " - " + corredores[0].getDistanciaRecorrida() + " metros", SwingConstants.CENTER);
    JLabel segundoLugar = new JLabel("2do Lugar: " + corredores[1].getNombre() + " - " + corredores[1].getDistanciaRecorrida() + " metros", SwingConstants.CENTER);
    JLabel tercerLugar = new JLabel("3er Lugar: " + corredores[2].getNombre() + " - " + corredores[2].getDistanciaRecorrida() + " metros", SwingConstants.CENTER);
    JLabel tiempoCarrera = new JLabel("Tiempo de carrera: " + tiempo + " milisegundos", SwingConstants.CENTER);

    panelPodio.add(titulo);
    panelPodio.add(new JLabel());
    panelPodio.add(primerLugar);
    panelPodio.add(segundoLugar);
    panelPodio.add(tercerLugar);
    panelPodio.add(tiempoCarrera);
    panelPodio.add(new JLabel());
    panelPodio.add(new JLabel());

    ventanaPodio.add(panelPodio);
    ventanaPodio.pack();
    ventanaPodio.setLocationRelativeTo(null);
    ventanaPodio.setVisible(true);

}
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel4 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        carnegro = new javax.swing.JLabel();
        carverde = new javax.swing.JLabel();
        carrojo = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Carrera = new javax.swing.JButton();
        fin = new javax.swing.JButton();
        aa = new javax.swing.JLabel();
        regre = new javax.swing.JButton();
        btnFin = new javax.swing.JButton();

        jLabel4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/image (4)_1.jpg"))); // NOI18N
        jLabel4.setText("jLabel1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        carnegro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/carro negro.png"))); // NOI18N
        carnegro.setLabelFor(jLabel4);
        carnegro.setText("jLabel7");
        jPanel1.add(carnegro, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 330, 200, 110));

        carverde.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/car-g4663b3883_640 (1).png"))); // NOI18N
        carverde.setLabelFor(jLabel4);
        carverde.setText("jLabel7");
        jPanel1.add(carverde, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 200, 110));

        carrojo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/rojo.png"))); // NOI18N
        carrojo.setLabelFor(jLabel4);
        carrojo.setText("jLabel7");
        jPanel1.add(carrojo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 580, 200, 110));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/image (4)_1.jpg"))); // NOI18N
        jLabel3.setText("jLabel1");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 856, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/image (4)_1.jpg"))); // NOI18N
        jLabel5.setText("jLabel1");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 510, 856, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/image (4)_1.jpg"))); // NOI18N
        jLabel7.setText("jLabel1");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 856, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, 0, 900, 760));

        Carrera.setText("Comenzar Carrera");
        Carrera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarreraActionPerformed(evt);
            }
        });
        getContentPane().add(Carrera, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 780, 230, 50));

        fin.setText("Finalizar");
        fin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                finActionPerformed(evt);
            }
        });
        getContentPane().add(fin, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 780, 110, 50));

        aa.setFont(new java.awt.Font("Impact", 0, 18)); // NOI18N
        aa.setForeground(new java.awt.Color(255, 51, 51));
        aa.setText("00:00");
        getContentPane().add(aa, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 780, 240, 50));

        regre.setText("Regresar");
        regre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                regreActionPerformed(evt);
            }
        });
        getContentPane().add(regre, new org.netbeans.lib.awtextra.AbsoluteConstraints(620, 780, 120, 50));

        btnFin.setText("FIN");
        btnFin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFinActionPerformed(evt);
            }
        });
        getContentPane().add(btnFin, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 780, 90, 50));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CarreraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarreraActionPerformed
        movimiento();
        reproducirAudio();
        iniciarCronometro();
    }//GEN-LAST:event_CarreraActionPerformed

    private void finActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_finActionPerformed
        detenerAudio();

//detenerCronometro();

        terminarCarrera();
    }//GEN-LAST:event_finActionPerformed

    private void regreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regreActionPerformed
        volver();

    }//GEN-LAST:event_regreActionPerformed

    private void btnFinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFinActionPerformed
        // TODO add your handling code here:
       


    }//GEN-LAST:event_btnFinActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {

        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Carrera.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Carrera.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Carrera.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Carrera.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                
                new Carrera().setVisible(true);
                
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Carrera;
    private javax.swing.JLabel aa;
    private javax.swing.JButton btnFin;
    private javax.swing.JLabel carnegro;
    private javax.swing.JLabel carrojo;
    private javax.swing.JLabel carverde;
    private javax.swing.JButton fin;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JButton regre;
    // End of variables declaration//GEN-END:variables
}
