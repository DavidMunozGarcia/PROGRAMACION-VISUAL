import java.awt.*;
import javax.swing.*;

public class Podio extends JFrame {
    private JLabel primerLugar, segundoLugar, tercerLugar;

    public Podio(String ganador, long tiempo) {
        super("Podio");

        setLayout(new GridLayout(4, 1));

        JLabel titulo = new JLabel("Resultados de la carrera", JLabel.CENTER);
        primerLugar = new JLabel("", JLabel.CENTER);
        segundoLugar = new JLabel("", JLabel.CENTER);
        tercerLugar = new JLabel("", JLabel.CENTER);

        primerLugar.setFont(new Font("Serif", Font.BOLD, 20));
        segundoLugar.setFont(new Font("Serif", Font.PLAIN, 18));
        tercerLugar.setFont(new Font("Serif", Font.PLAIN, 16));

        primerLugar.setText("Ganador: " + ganador + " - Tiempo: " + tiempo + " segundos");
        segundoLugar.setText("Segundo lugar: ");
        tercerLugar.setText("Tercer lugar: ");

        add(titulo);
        add(primerLugar);
        add(segundoLugar);
        add(tercerLugar);

        setSize(400, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public void setSegundoLugar(String nombre) {
        segundoLugar.setText("Segundo lugar: " + nombre);
    }

    public void setTercerLugar(String nombre) {
        tercerLugar.setText("Tercer lugar: " + nombre);
    }

    public static void main(String[] args) {
        Podio podio = new Podio("Juan", 45);
        podio.setSegundoLugar("Pedro");
        podio.setTercerLugar("María");
    }
}
