
package Guia;

public class GuiapractucaMunoz {

private String nom;
private String ape;
private String ape2;

    public GuiapractucaMunoz() {
    }

    public GuiapractucaMunoz(String nom, String ape, String ape2) {
        this.nom = nom;
        this.ape = ape;
        this.ape2 = ape2;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getApe() {
        return ape;
    }

    public void setApe(String ape) {
        this.ape = ape;
    }

    public String getApe2() {
        return ape2;
    }

    public void setApe2(String ape2) {
        this.ape2 = ape2;
    }

    @Override
    public String toString() {
        return "GuiapractucaMunoz{" + "nom=" + nom + ", ape=" + ape + ", ape2=" + ape2 + '}';
    }



}
